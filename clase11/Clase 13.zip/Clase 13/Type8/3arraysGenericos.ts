
// Array Generico
let Heroes: Array<string> = ["Flash", "Superman", "Batman"];

// Array Explicito
let villanos:string[] = ["Lex Luthor", "The Joker"];





