<?php
    $a = $_POST['num1'];
    $b = $_POST['num2'];

    sleep(5);

    echo $a + $b;


?>